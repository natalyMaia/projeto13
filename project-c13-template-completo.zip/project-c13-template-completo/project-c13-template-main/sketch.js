var PLAY = 1;
var END = 0;
var gameState = PLAY;
var garden,rabbit,apple,orange,red;
var gardenG,rabbitG,appleG,orangeG,redG;
var gardenImg,rabbitImg,appleImg,orangeImg,redImg;
var The_end;
var Hit = 0;

var appl, oran, redl;
var score1 = 0, score2 = 0, score3 = 0;

var gameOver = "GameOver";


function preload(){
  gardenImg = loadImage("garden.png");
  rabbitImg = loadImage("rabbit.png");
  appleImg = loadImage("apple.png");
  orangeImg = loadImage("orangeLeaf.png");
  redImg = loadImage("redImage.png");
  //score1 = loadImage("apple.png"); 

}

function setup(){
  
  createCanvas(400,400);
  
  // mover o fundo
  garden=createSprite(200,200);
  garden.addImage(gardenImg);

  //criar sprite do coelho
  rabbit = createSprite(180,340,30,30);
  rabbit.scale =0.09;
  rabbit.addImage(rabbitImg);
  //rabbit.x = World.mouseX;
  
  appl=createSprite(20, 30);
  appl.addImage(appleImg);
  appl.scale = 0.05;
  //appl.depth = 3;

  redl=createSprite(20, 70);
  redl.addImage(redImg);
  redl.scale = 0.05;

  oran=createSprite(20, 110);
  oran.addImage(orangeImg);
  oran.scale = 0.07;

  appleG= new Group();
  orangeG= new Group();
  redG= new Group();

  The_end = createSprite(200,400,400,5);
  The_end.shapecolor = "green";

  gameOver.visible = false;

  //appl=createSprite(10, 10);
  //appl.addImage(appleImg);
  //appl.scale = 0.07;
  //appl.depth = 3;

}


function draw() {
  background(0);
  
  if(gameState === PLAY) {

    rabbit.x = World.mouseX;

    edges= createEdgeSprites();
    rabbit.collide(edges);

    if (rabbit.isTouching(appleG)){
      //
      appleG.destroyEach();
      score1 = score1 + 1;
      /*if (Hit == 5) {
        gameState = END
      }*/
    }

    if (rabbit.isTouching(redG)) {
      redG.destroyEach();
      score2 = score2 + 1;
    }

    if (rabbit.isTouching(orangeG)) {
      orangeG.destroyEach();
      score3 = score3 + 1;
    }

    var select_sprites = Math.round(random(1,3));

    if (frameCount % 40 == 0) {
      if (select_sprites == 1) {
        createApples();
      } else if (select_sprites == 2) {
        createOrange();
      }else {
      createRed();
      }
    }
  
    if(appleG.isTouching(The_end)){
      appleG.destroyEach();
      Hit = Hit + 1;
    }
    if(redG.isTouching(The_end)) {
      redG.destroyEach();
      Hit = Hit + 1;
    }
    if(orangeG.isTouching(The_end)) {
      orangeG.destroyEach();
      Hit = Hit + 1;
    

      //text("Game Over!",170,160);

      if (Hit == 5){
        gameState = END;
        //rabbit.destroy();
      }
    }
  }    

  if (gameState === END) {
    /*textSize(20);
    fill("white");
    text("GameOver ", 200, 200);
    text.depth = 5;*/
    gameOver.visible = true;

    //defina a velocidade de cada objeto do jogo para 0
    rabbit.destroy();
    appleG.setVelocityXEach(0);
    orangeG.setVelocityXEach(0);
    redG.setVelocityXEach(0);
  }

  drawSprites();
  
  textSize(20);
  fill("white");
  text(" X " + score1, 30, 40);
  text(" X " + score2, 30, 80);
  text(" X " + score3, 30, 120);

  textSize(20);
  fill("black");
  text("Hit: " + Hit, 30, 380);

  //gameOver.visible = false;

  if (gameState === END) {
    textSize(40);
    fill("red");
    text("GameOver ", 110, 200);
    //text.depth = 5;
    /* gameOver.visible = true*/
  }

}

function createApples() {
  apple = createSprite(random(50, 350),40, 10, 10);
  apple.addImage(appleImg);
  apple.scale = 0.07;
  apple.velocityY = 6;
  apple.lifetime = 150;
  appleG.add(apple);
}

function createOrange() {
  orange = createSprite(random(50, 350),40, 10, 10);
  orange.addImage(orangeImg);
  orange.scale = 0.08;
  orange.velocityY = 6;
  orange.lifetime = 150;
  orangeG.add(orange);
}

function createRed() {
  red = createSprite(random(50, 350),40, 10, 10);
  red.addImage(redImg);
  red.scale = 0.06;
  red.velocityY = 6;
  red.lifetime = 150;
  redG.add(red);
}